function [ locs1, locs2] = matchPics( I1, I2 )
%MATCHPICS Extract features, obtain their descriptors, and match them!

%% Convert images to grayscale, if necessary
I2_gray = rgb2gray(I2);

%% Detect features in both images

p1 = detectFASTFeatures(I1);
p2 = detectFASTFeatures(rgb2gray(I2));

%% Obtain descriptors for the computed feature locations

[features1, locs1] = computeBrief(I1, p1.Location);
[features2, locs2] = computeBrief(I2_gray, p2.Location);

%% Match features using the descriptors

indexPairs = matchFeatures(features1,features2, 'MaxRatio',0.7, 'MatchThreshold', 10);

locs1 = locs1(indexPairs(:,1),:);
locs2 = locs2(indexPairs(:,2),:);

% showMatchedFeatures(I1,I2,locs1,locs2, 'montage');

end

