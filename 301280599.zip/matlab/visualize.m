%% images for computeH, computeH_norma and computeH_ransac
clear all;
close all;

cv_img = imread('../data/cv_cover.jpg');
desk_img = imread('../data/cv_desk.png');

[locs1, locs2] = matchPics(cv_img, desk_img);

samples = 10;
loc = randperm(length(locs2), samples);
x1 = locs1(loc,:);
x2 = locs2(loc,:);
homogenous_x1 = [x1 ones([samples,1])]';

%% visualize 4.3, 4.4 
%% visualization for 4.5 is written at the bottom of computeH_ransac.m

H = computeH(x2, x1);

% H = computeH_norm(x2, x1);

transformed_x2 = (H * homogenous_x1)';
transformed_x2 = transformed_x2(:, 1:2)./ transformed_x2(:,3);
showMatchedFeatures(cv_img, desk_img , x1 ,transformed_x2(:,1:2), 'montage');

