function [ bestH2to1, inliers] = computeH_ransac( locs1, locs2)
%COMPUTEH_RANSAC A method to compute the best fitting homography given a
%list of matching points.

%Q2.2.3
len = length(locs2);
samplePts = 4;
threshold = 15;
% threshold = 20;
maxCount = 0;
inliers = [];
maxloc = [];

for k = 1 : 1000
    
    %% compute Homography H with 4 randomly sampled points
    loc = randperm(len, samplePts);
    
    H = computeH_norm(locs1(loc,:), locs2(loc,:));
    
    %% compute distance between the locs1_transformed_from_locs2 and the real locs1
    homogenous_pts = [locs2 ones([len,1])]';
    transformed_locs1 = (H * homogenous_pts)';
    transformed_locs1 = transformed_locs1(:, 1:2)./ transformed_locs1(:,3);
    distance = transformed_locs1 - locs1;
    
%     distance = distance(:,1) + distance(:,2);
    
%     distance = abs(distance(:,1)) + abs(distance(:,2));
 
    distance = sqrt(distance(:,1).^2 + distance(:,2).^2);
    
    %% count inliers based less than the threshold
    inliers_temp = distance < threshold;
    count = sum( inliers_temp ) - samplePts;
    if maxCount < count
        maxCount = count;
        inliers = inliers_temp;
        maxloc = loc;
    end
    
end

bestH2to1 = computeH_norm(locs1(inliers,:), locs2(inliers,:));

%% visualization

% cv_img = imread('../data/cv_cover.jpg');
% desk_img = imread('../data/cv_desk.png');
% showMatchedFeatures(cv_img, desk_img , locs1(maxloc,:), locs2(maxloc,:), 'montage');
% showMatchedFeatures(cv_img, desk_img , locs1(inliers,:), locs2(inliers,:), 'montage');
end

