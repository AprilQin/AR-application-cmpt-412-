% Q3.3.1
clear all;
close all;

cv_img = imread('../data/cv_cover.jpg');
cv_height = size(cv_img, 1);
cv_width = size(cv_img, 2);

panda_vid = loadVid('../data/ar_source.mov');
panda_height = size(panda_vid(1).cdata, 1);
panda_width = size(panda_vid(1).cdata, 2);

crop_width = panda_height / (cv_height/cv_width);
xmin = (panda_width - crop_width)/2;

book_vid = loadVid('../data/book.mov');

output_mov = VideoWriter('../results/pandarize.avi');
open(output_mov);

% for i = 1 : length(panda_vid)
    
for i = 1 : length(panda_vid)
    i
    
    %% compute the H between the a book video frame and the cover image
    book_frame = book_vid(i).cdata;
 
    [locs1, locs2] = matchPicSurf(cv_img, book_frame);
    
    if length(locs1) < 4
        continue;
    end
    
    [bestH2to1, ~] = computeH_ransac(locs1, locs2);
    
    %% crop and resize a panda video frame to be the same size as the cover image
    panda_frame = panda_vid(i).cdata;
    panda_frame = imcrop(panda_frame, [xmin, 45, crop_width, panda_height-90]);
%     imshow(panda_frame);
    
    panda_frame = imresize(panda_frame, [cv_height, cv_width-2]);
    panda_frame = panda_frame + 1;
    
    %% composite
    frame = compositeH(double(inv(bestH2to1)), panda_frame, book_frame);
    imshow(frame);
    writeVideo(output_mov, frame);
end

close(output_mov);


