function [ locs1, locs2] = matchPicSurf( I1, I2 )
%MATCHPICS Extract features, obtain their descriptors, and match them!

%% Convert images to grayscale, if necessary
I2_gray = rgb2gray(I2);

%% Detect features in both images

p1 = detectSURFFeatures(I1);
p2 = detectSURFFeatures(I2_gray);

%% Obtain descriptors for the computed feature locations

[features1,locs1] = extractFeatures(I1,p1.Location,'Method','SURF');
[features2,locs2] = extractFeatures(I2_gray,p2.Location,'Method','SURF');

%% Match features using the descriptors

indexPairs = matchFeatures(features1,features2, 'MaxRatio',0.6, 'MatchThreshold', 10);

locs1 = locs1(indexPairs(:,1),:).Location;
locs2 = locs2(indexPairs(:,2),:).Location;

% showMatchedFeatures(I1,I2,locs1,locs2, 'montage');

end

