% Your solution to Q2.1.5 goes here!

%% Read the image and convert to grayscale, if necessary
cv_img = imread('../data/cv_cover.jpg');

%% Compute the features and descriptors
arr = [];
arr_surf = [];

% for i = 0:36
for i = 3:3:9 
%% for visualization: for i = 3:3:9 

    %% Rotate image    
    cv_img_rot = imrotate(cv_img, i*10);
    
    %% Compute features and descriptors
    
    p1 = detectFASTFeatures(cv_img);
    p2 = detectFASTFeatures(cv_img_rot);
    
    p1_surf = detectSURFFeatures(cv_img);
    p2_surf = detectSURFFeatures(cv_img_rot);

    %% Match features
    
    [features1, locs1] = computeBrief(cv_img, p1.Location);
    [features2, locs2] = computeBrief(cv_img_rot, p2.Location);
    indexPairs = matchFeatures(features1,features2, 'MaxRatio',0.7, 'MatchThreshold', 10);

%     visualization    
%     locs1 = locs1(indexPairs(:,1),:);
%     locs2 = locs2(indexPairs(:,2),:);
%     showMatchedFeatures(cv_img,cv_img_rot,locs1,locs2, 'montage');

    [features1,locs1] = extractFeatures(cv_img,p1_surf.Location,'Method','SURF');
    [features2,locs2] = extractFeatures(cv_img_rot,p2_surf.Location,'Method','SURF');
    indexPairs_surf = matchFeatures(features1,features2, 'MaxRatio',0.7, 'MatchThreshold', 10);
    
%     visualization   
%     locs1 = locs1(indexPairs_surf(:,1),:);
%     locs2 = locs2(indexPairs_surf(:,2),:);
%     showMatchedFeatures(cv_img,cv_img_rot,locs1,locs2, 'montage');
     
    %% Update histogram
    arr(i+1, 1) =  i*10;
    arr(i+1, 2) = length(indexPairs) ;
    
    arr_surf(i+1, 1) =  i*10;
    arr_surf(i+1, 2) = length(indexPairs_surf);

end

%% Display histogram

figure
plot(arr(:,1), arr(:,2));

figure
plot(arr_surf(:,1), arr_surf(:,2));


